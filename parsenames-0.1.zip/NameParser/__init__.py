__title__ = 'NameParser'
__version__ = '0.1'
__author__ = 'Ali GOREN <goren.ali@yandex.com>'
__repo__ = 'https://github.com/aligoren/NameParser'
__license__ = 'Apache v2.0 License'

from .name import NameParser
from .name import getName
